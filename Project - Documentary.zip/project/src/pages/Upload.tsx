import React from 'react';
import UploadForm from '../components/UploadForm';

const Upload: React.FC = () => {
  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Upload Document</h1>
        <p className="text-gray-600">
          Upload text documents to analyze and ask questions about their content
        </p>
      </div>
      <UploadForm />
    </div>
  );
};

export default Upload;