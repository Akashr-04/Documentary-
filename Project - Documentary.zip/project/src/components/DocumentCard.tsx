import React from 'react';
import { useNavigate } from 'react-router-dom';
import { File, FileText, Clock, Check, AlertTriangle } from 'lucide-react';
import { DocumentType } from '../types';

interface DocumentCardProps {
  document: DocumentType;
  onClick?: () => void;
}

const DocumentCard: React.FC<DocumentCardProps> = ({ document, onClick }) => {
  const navigate = useNavigate();
  
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' B';
    else if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    else return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'processing':
        return <Clock className="w-5 h-5 text-yellow-500" />;
      case 'completed':
        return <Check className="w-5 h-5 text-green-500" />;
      case 'error':
        return <AlertTriangle className="w-5 h-5 text-red-500" />;
      default:
        return <File className="w-5 h-5 text-gray-400" />;
    }
  };

  const handleClick = () => {
    if (onClick) {
      onClick();
    } else {
      navigate(`/qa/${document.id}`);
    }
  };

  return (
    <div 
      className="card hover:shadow-lg cursor-pointer transition-all duration-200 animate-fade-in"
      onClick={handleClick}
    >
      <div className="p-4 border-b border-gray-100 flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <FileText className="w-6 h-6 text-primary-600" />
          <h3 className="font-medium text-lg">{document.title}</h3>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-gray-500">{document.fileType.toUpperCase()}</span>
          {getStatusIcon(document.status)}
        </div>
      </div>
      <div className="p-4 text-sm text-gray-600">
        <div className="grid grid-cols-2 gap-2">
          <div>
            <p className="text-gray-500">Size:</p>
            <p>{formatFileSize(document.fileSize)}</p>
          </div>
          <div>
            <p className="text-gray-500">Pages:</p>
            <p>{document.pageCount}</p>
          </div>
          <div>
            <p className="text-gray-500">Created:</p>
            <p>{formatDate(document.createdAt)}</p>
          </div>
          <div>
            <p className="text-gray-500">Status:</p>
            <p className="capitalize">{document.status}</p>
          </div>
        </div>
      </div>
      <div className="p-3 bg-gray-50 flex justify-end">
        <button 
          className="btn-outline text-sm py-1 px-3"
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/qa/${document.id}`);
          }}
        >
          Ask Questions
        </button>
      </div>
    </div>
  );
};

export default DocumentCard;