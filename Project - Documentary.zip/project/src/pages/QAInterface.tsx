import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, FileQuestion, Loader } from 'lucide-react';
import QuestionForm from '../components/QuestionForm';
import Answer from '../components/Answer';
import { useDocuments } from '../context/DocumentContext';
import { QuestionAnswerType } from '../types';

const QAInterface: React.FC = () => {
  const { documentId } = useParams<{ documentId?: string }>();
  const navigate = useNavigate();
  const { documents, setSelectedDocument } = useDocuments();
  const [qaHistory, setQaHistory] = useState<QuestionAnswerType[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (documentId) {
      const document = documents.find((doc) => doc.id === documentId);
      if (document) {
        setSelectedDocument(document);
      } else if (!documents.length) {
        // If documents not loaded yet, we'll wait
      } else {
        // Document not found
        navigate('/');
      }
    } else if (documents.length > 0) {
      // No document selected, redirect to first document
      navigate(`/qa/${documents[0].id}`);
    }

    return () => {
      setSelectedDocument(null);
    };
  }, [documentId, documents, navigate, setSelectedDocument]);

  const handleAnswerReceived = (qa: QuestionAnswerType) => {
    setQaHistory((prev) => [...prev, qa]);
  };

  const currentDocument = documents.find((doc) => doc.id === documentId);

  if (!documentId || !currentDocument) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-center">
          <FileQuestion className="w-12 h-12 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-600">Select a document to start asking questions</p>
        </div>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <button
          onClick={() => navigate('/')}
          className="flex items-center text-primary-700 hover:text-primary-800 mb-3"
        >
          <ArrowLeft className="w-4 h-4 mr-1" />
          Back to Documents
        </button>
        
        <h1 className="text-3xl font-bold mb-2">Q&A: {currentDocument.title}</h1>
        <p className="text-gray-600">
          Ask questions about this document and get AI-powered answers
        </p>
      </div>

      <div className="bg-white rounded-lg shadow-md p-4 md:p-6">
        <div className="mb-6 overflow-y-auto max-h-[60vh] p-2">
          {qaHistory.length === 0 ? (
            <div className="text-center py-8">
              <FileQuestion className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-700 mb-2">
                No questions asked yet
              </h3>
              <p className="text-gray-500">
                Ask a question below to get started
              </p>
            </div>
          ) : (
            qaHistory.map((qa, index) => (
              <Answer key={index} qa={qa} />
            ))
          )}
          
          {isLoading && (
            <div className="flex items-center space-x-2 p-3 bg-gray-50 rounded-lg animate-pulse">
              <Loader className="w-5 h-5 text-primary-500 animate-spin" />
              <span className="text-gray-500">Generating answer...</span>
            </div>
          )}
        </div>

        <QuestionForm
          documentId={documentId}
          onAnswerReceived={handleAnswerReceived}
          isLoading={isLoading}
          setIsLoading={setIsLoading}
        />
      </div>
    </div>
  );
};

export default QAInterface;