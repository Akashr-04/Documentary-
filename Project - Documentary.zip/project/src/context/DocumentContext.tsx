import React, { createContext, useContext, useState, useEffect } from 'react';
import { DocumentType, ChunkType } from '../types';
import { fetchDocuments } from '../services/api';

interface DocumentContextType {
  documents: DocumentType[];
  isLoading: boolean;
  error: string | null;
  selectedDocument: DocumentType | null;
  setSelectedDocument: (document: DocumentType | null) => void;
  refreshDocuments: () => Promise<void>;
}

const DocumentContext = createContext<DocumentContextType | undefined>(undefined);

export const useDocuments = () => {
  const context = useContext(DocumentContext);
  if (!context) {
    throw new Error('useDocuments must be used within a DocumentProvider');
  }
  return context;
};

export const DocumentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [documents, setDocuments] = useState<DocumentType[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedDocument, setSelectedDocument] = useState<DocumentType | null>(null);

  const refreshDocuments = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await fetchDocuments();
      setDocuments(data);
    } catch (err) {
      setError('Failed to fetch documents');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshDocuments();
  }, []);

  return (
    <DocumentContext.Provider
      value={{
        documents,
        isLoading,
        error,
        selectedDocument,
        setSelectedDocument,
        refreshDocuments,
      }}
    >
      {children}
    </DocumentContext.Provider>
  );
};