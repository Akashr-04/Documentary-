import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { QuestionAnswerType } from '../types';

interface AnswerProps {
  qa: QuestionAnswerType;
}

const Answer: React.FC<AnswerProps> = ({ qa }) => {
  const [showSources, setShowSources] = useState(false);

  const formatTime = (timestamp: string): string => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="mb-6 animate-slide-up">
      <div className="mb-2 text-sm text-gray-500">
        {formatTime(qa.timestamp)}
      </div>
      
      <div className="flex flex-col space-y-3">
        <div className="bg-gray-100 p-3 rounded-lg rounded-bl-none self-start max-w-[85%]">
          <p className="text-gray-800">{qa.question}</p>
        </div>
        
        <div className="bg-primary-100 p-4 rounded-lg rounded-br-none self-end max-w-[85%]">
          <p className="text-gray-800 whitespace-pre-line">{qa.answer}</p>
          
          {qa.sources.length > 0 && (
            <div className="mt-3">
              <button
                onClick={() => setShowSources(!showSources)}
                className="flex items-center text-sm text-primary-700 hover:text-primary-800"
              >
                {showSources ? (
                  <>
                    <ChevronUp className="w-4 h-4 mr-1" />
                    Hide sources
                  </>
                ) : (
                  <>
                    <ChevronDown className="w-4 h-4 mr-1" />
                    Show sources ({qa.sources.length})
                  </>
                )}
              </button>
              
              {showSources && (
                <div className="mt-2 space-y-2">
                  {qa.sources.map((source, index) => (
                    <div key={index} className="bg-white p-2 rounded border border-gray-200 text-sm">
                      <div className="flex justify-between text-xs text-gray-500 mb-1">
                        <span>Page {source.pageNumbers.join(', ')}</span>
                        <span>Relevance: {(source.relevanceScore * 100).toFixed(0)}%</span>
                      </div>
                      <p className="text-gray-700">{source.content}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Answer;