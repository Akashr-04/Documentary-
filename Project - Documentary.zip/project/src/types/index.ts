export interface DocumentType {
  id: string;
  title: string;
  filePath: string;
  fileType: string;
  fileSize: number;
  pageCount: number;
  status: 'processing' | 'completed' | 'error';
  createdAt: string;
  updatedAt: string;
}

export interface ChunkType {
  id: string;
  documentId: string;
  chunkIndex: number;
  content: string;
  pageNumbers: number[];
  embeddingId: string;
}

export interface QuestionAnswerType {
  id: string;
  documentId: string;
  question: string;
  answer: string;
  sources: SourceType[];
  timestamp: string;
}

export interface SourceType {
  chunkId: string;
  content: string;
  pageNumbers: number[];
  relevanceScore: number;
}