import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FileText, Upload, AlertCircle, RefreshCw } from 'lucide-react';
import DocumentCard from '../components/DocumentCard';
import { useDocuments } from '../context/DocumentContext';

const Dashboard: React.FC = () => {
  const { documents, isLoading, error, refreshDocuments } = useDocuments();
  const navigate = useNavigate();

  return (
    <div className="animate-fade-in">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Document Library</h1>
          <p className="text-gray-600">Manage and explore your uploaded documents</p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-3">
          <button
            onClick={() => refreshDocuments()}
            className="btn btn-outline flex items-center"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </button>
          <button
            onClick={() => navigate('/upload')}
            className="btn btn-primary flex items-center"
          >
            <Upload className="w-4 h-4 mr-2" />
            Upload
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-pulse-slow flex flex-col items-center">
            <RefreshCw className="w-10 h-10 text-primary-500 animate-spin" />
            <p className="mt-4 text-gray-600">Loading documents...</p>
          </div>
        </div>
      ) : error ? (
        <div className="bg-red-50 p-4 rounded-lg flex items-start">
          <AlertCircle className="w-5 h-5 text-red-500 mt-0.5 mr-3 flex-shrink-0" />
          <div>
            <h3 className="font-medium text-red-800">Error loading documents</h3>
            <p className="text-red-700 mt-1">{error}</p>
            <button
              onClick={() => refreshDocuments()}
              className="mt-2 text-red-700 underline hover:text-red-800"
            >
              Try again
            </button>
          </div>
        </div>
      ) : documents.length === 0 ? (
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-medium text-gray-700 mb-2">No documents yet</h3>
          <p className="text-gray-500 mb-6">
            Upload your first document to start asking questions.
          </p>
          <button
            onClick={() => navigate('/upload')}
            className="btn btn-primary inline-flex items-center"
          >
            <Upload className="w-4 h-4 mr-2" />
            Upload Document
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {documents.map((document) => (
            <DocumentCard
              key={document.id}
              document={document}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default Dashboard;